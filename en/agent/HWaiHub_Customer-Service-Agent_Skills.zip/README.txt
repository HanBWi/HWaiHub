HWaiHub - Customer Service Agent: six skills for Microsoft 365 Copilot Agent Builder

1. Unzip this download once. You get six small ZIP files. Leave those zipped.
2. In Agent Builder open Configure, find Skills and select Add.
3. Upload one ZIP file, then repeat for the others (up to 8 skills per agent).

Add this block at the end of your agent instructions:

SKILLS
For every new customer message use customer-inquiry-analysis first.
If it shows an escalation signal, use case-escalation. Otherwise use personalized-reply.
Check every customer-facing text with quality-policy-control before showing it.
Use crm-data-preparation when I ask for a CRM entry.
Use sales-follow-up when I ask to follow up.
Show: topic and opportunity, priority, draft reply, next action.
Never send anything. Never invent information.

To change a default, edit SKILL.md inside a skill ZIP and zip it again (SKILL.md at the top level).
Skills prepare only. They do not send emails, write into a CRM or forward cases.
Not legal advice. Check results before you use them. Availability depends on your plan and admin settings.
Independent material, not affiliated with or endorsed by Microsoft.
HWaiHub - hwaihub.com
